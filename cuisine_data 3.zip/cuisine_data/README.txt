CUISINE NETWORKS - FIGURES, DATA AND NOTEBOOK
=============================================
cuisine_graphs.ipynb   Notebook that rebuilds every figure and table from data/ (run all cells, ~1 minute). Already executed once; outputs are saved in it.
data/
  all_cuisines_combined.csv          course recipe table (region, cuisine, recipe, ingredient)
  FiltredIngredientcuisines65.gexf   the TF-IDF network supplied with the project (compared with our rebuilt graph in section 8 of the notebook)
  religion_by_cuisine.csv            Pew 2020 religion shares per cuisine (via Wikipedia "Religions by country";
  religion_by_country.csv            same data per country
  nodes_with_attributes.csv          cuisine -> country, location, continent, official languages, coloniser group (language/colonial coding done by hand, unverified)
  world.geojson                      country outlines for the maps
figures/   the 11 pages of cuisine_figures.pdf as PNG files

Setup: Python 3 with numpy, pandas, networkx, scikit-learn, matplotlib, scipy, jupyter. Figures use the Inter font if installed (otherwise matplotlib falls back to its default).
Choices: all "(general)" cuisines removed (144 cuisines kept, 563 ingredients); ingredients used by a single cuisine or by >80% of cuisines are dropped for TF-IDF.
Check against your GEXF: with the 0.65 filter and cosine >= 0.3, our graph shares 1,002 of the edges (Jaccard 0.93) and edge weights correlate at 0.993.
